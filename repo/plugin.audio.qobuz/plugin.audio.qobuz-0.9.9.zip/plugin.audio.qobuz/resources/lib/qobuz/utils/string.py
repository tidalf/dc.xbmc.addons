def color(color, str):
    str = '[COLOR=' + color + ']' + str + '[/COLOR]'
    return str
